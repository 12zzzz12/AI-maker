package com.example.real;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.firebase.messaging.FirebaseMessaging;

import org.json.JSONException;
import org.json.JSONObject;




public class MainActivity extends AppCompatActivity {

    //알림창 이름값
    public static String fname = "";
    public static String imgpath = "";

    public void onCreate(Bundle savedInstanceState) {
        FirebaseMessaging.getInstance().subscribeToTopic("news");


        //버튼 화면 설정
        setContentView(R.layout.activity_main);
        super.onCreate(savedInstanceState);

        Button btn = findViewById(R.id.loginbtn);
        TextView tv = findViewById(R.id.registerbtn);

        final EditText et_u_mail = findViewById(R.id.u_mail);
        final EditText et_u_pw = findViewById(R.id.u_pw);


        btn.setOnClickListener(new Button.OnClickListener() { //로그인 버튼
            public void onClick(View v) {
                String u_mail = et_u_mail.getText().toString();
                String u_pw = et_u_pw.getText().toString();

                if (u_mail.equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    AlertDialog dialog = builder.setMessage("이메일을 확인해주세요.")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                } else if (u_pw.equals("")) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                    AlertDialog dialog = builder.setMessage("비밀번호를 확인해주세요.")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                }
                Response.Listener<String> responseListener = new Response.Listener<String>() {
                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");

                            //알림창에 쓸 이름값 가져오기
                            fname = jsonObject.getString("u_name");

                            imgpath =jsonObject.getString("imgpath");
                            if (success) { //로그인 성공한 경우
                              //  Toast.makeText(getApplicationContext(), "로그인 성공", Toast.LENGTH_SHORT).show();
                                Toast.makeText(getApplicationContext(), imgpath, Toast.LENGTH_SHORT).show();

                                //화면전환
                                Intent intent = new Intent(MainActivity.this, alarm.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(getApplicationContext(), "로그인 실패", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                LoginRequest loginRequest = new LoginRequest(u_mail, u_pw, responseListener);
                RequestQueue queue = Volley.newRequestQueue(MainActivity.this);
                queue.add(loginRequest);

            }
        });


        tv.setOnClickListener(new Button.OnClickListener() {
            public void onClick(View v) { //register 버튼
                Intent intent = new Intent(MainActivity.this, register.class);
                startActivity(intent);
            }
        });

    }
}
