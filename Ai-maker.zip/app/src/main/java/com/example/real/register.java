package com.example.real;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.toolbox.Volley;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import org.json.JSONException;
import org.json.JSONObject;

public class register extends Activity {

    private EditText et_mail, et_pw, et_pw2, et_name;

    public void onCreate(Bundle savedInstanceState) {

        setContentView(R.layout.activity_register);
        super.onCreate(savedInstanceState);

        final EditText et_mail = findViewById(R.id.u_mail_reg);
        final EditText et_pw = findViewById(R.id.u_pw_reg);
        final EditText et_pw2 = findViewById(R.id.u_pw_reg2);
        final EditText et_name = findViewById(R.id.u_name);

        Button btn_reg = findViewById(R.id.btn_reg);
        btn_reg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String u_mail = et_mail.getText().toString();
                String u_pw = et_pw.getText().toString();
                String u_pw2 = et_pw2.getText().toString();
                String u_name = et_name.getText().toString();
                final String[] token2 = {""};

                FirebaseInstanceId.getInstance().getInstanceId()
                        .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                            @Override
                            public void onComplete(@NonNull Task<InstanceIdResult> task) {
                                if (!task.isSuccessful()) {
                                    Log.w("FIREBASE", "getInstanceId failed", task.getException());
                                    return;
                                }
                                token2[0] = task.getResult().getToken();
                                Log.d("FIREBASE=", token2[0]);




                                SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
                                SharedPreferences.Editor editor = pref.edit();
                                editor.putString("token", token2[0]);
                                editor.apply();

                            }
                        });


                if (u_name.equals("")) { //이메일이 빈칸일 때
                    AlertDialog.Builder builder = new AlertDialog.Builder(register.this);
                    AlertDialog dialog = builder.setMessage("이름을 확인해주세요.")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                } else if (u_mail.equals("")) { //이름이 빈칸일 때
                    AlertDialog.Builder builder = new AlertDialog.Builder(register.this);
                    AlertDialog dialog = builder.setMessage("이메일을 확인해주세요.")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                } else if (!u_pw.equals(u_pw2)) { //비밀번호 확인이 다를 때
                    AlertDialog.Builder builder = new AlertDialog.Builder(register.this);
                    AlertDialog dialog = builder.setMessage("비밀번호를 확인해주세요.")
                            .setPositiveButton("확인", null)
                            .create();
                    dialog.show();
                    return;
                }
                Response.Listener<String> responseListener = new Response.Listener<String>() {

                    public void onResponse(String response) {
                        try {
                            JSONObject jsonObject = new JSONObject(response);
                            boolean success = jsonObject.getBoolean("success");
                            if (success) { //로그인 성공한 경우
                                Toast.makeText(getApplicationContext(), "가입성공", Toast.LENGTH_SHORT).show();
                                //화면전환
                                Intent intent = new Intent(register.this, MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(getApplicationContext(), "가입실패", Toast.LENGTH_SHORT).show();
                            }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                };
                //토큰 값 저장
                SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
                String token =  pref.getString("token", "");


                //Toast.makeText(getApplicationContext(),token,Toast.LENGTH_SHORT).show();


                //registerrequest 호출
                RegisterRequest registeRequest = new RegisterRequest(u_mail, u_pw, u_name, token, responseListener);
                RequestQueue queue2 = Volley.newRequestQueue(register.this);
                queue2.add(registeRequest);



            }
        });
    }
}
