package com.example.real;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

public class alarm extends AppCompatActivity {
    TextView name;
    ImageView img1;
    final String al_imgpath = MainActivity.imgpath;
    Bitmap bitmap;
    Handler handler = new Handler();
    public void onCreate(Bundle savedInstanceState) {


        img1 = findViewById(R.id.imageView3);
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);


        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("FCM Log", "getInstanceId failed", task.getException());
                            return;
                        }
                        String token = task.getResult().getToken();
                        Log.d("FCM Log", "FCM 토큰" + token);
                        //  Toast.makeText(alarm.this,token,Toast.LENGTH_SHORT).show();
                    }
                });

        final Button btn = findViewById(R.id.button2);

        final View back = findViewById(R.id.back);

        name = findViewById(R.id.textView4);
        name.setText(MainActivity.fname);

        Thread t = new Thread(new Runnable() {
            @Override
            public void run() {    // 오래 거릴 작업을 구현한다
                // TODO Auto-generated method stub
                try {
                    // 걍 외우는게 좋다 -_-;
                    final ImageView iv = (ImageView) findViewById(R.id.imageView3);
                    URL url = new URL("http://118.67.129.164/maker/uploads/"+al_imgpath);
                    InputStream is = url.openStream();
                    final Bitmap bm = BitmapFactory.decodeStream(is);
                    //Handler handler = new Handler();
                    handler.post(new Runnable() {
                        @Override
                        public void run() {  // 화면에 그려줄 작업
                            iv.setImageBitmap(bm);
                        }
                    });
                    iv.setImageBitmap(bm); //비트맵 객체로 보여주기
                } catch (Exception e) {

                }

            }
        });
        t.start();



        /*
        Thread uThread = new Thread() {
            @Override
            public void run() {
                try {
                    URL url = new URL("http://118.67.129.164/maker/uploads/2.3.jpg");
                    HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                    conn.setDoInput(true); //Server 통신에서 입력 가능한 상태로 만듦
                    conn.connect(); //연결된 곳에 접속할 때 (connect() 호출해야 실제 통신 가능함)
                    InputStream is = conn.getInputStream(); //inputStream 값 가져오기
                    bitmap = BitmapFactory.decodeStream(is);

                } catch (MalformedURLException e) {
                    e.printStackTrace();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        };

        uThread.start();
        try {

            uThread.join();
            img1.setImageBitmap(bitmap);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        */
        //버튼 클릭시 메시지 화면띄우기
        btn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                showmessage();
            }
        });

    }


    public void showmessage() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("본인확인");
        builder.setMessage("문을 열까요?");

        builder.setPositiveButton("예", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 문이 열렸을 떄      라파 초록불 들어오게
                //img1.setImageResource(R.drawable.unlock);
                View bb = findViewById(R.id.back);
                bb.setBackgroundResource(R.color.unlockcolor);
            }
        });

        builder.setNegativeButton("아니오", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                // 문 여는거 거부      라파 빨간불
                //img1.setImageResource(R.drawable.lock);
                View bb = findViewById(R.id.back);
                bb.setBackgroundResource(R.color.lockcolor);
            }
        });
        AlertDialog alertDialog = builder.create();
        alertDialog.show();

    }


}
