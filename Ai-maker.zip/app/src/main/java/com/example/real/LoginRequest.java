package com.example.real;


import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.toolbox.StringRequest;

import java.util.HashMap;
import java.util.Map;

class LoginRequest extends StringRequest {
    final static private String URL = "http://118.67.129.164/maker/maker_login.php";
    private Map<String, String> map;

    public LoginRequest(String u_mail, String u_pw, Response.Listener<String> listener){
        super(Method.POST, URL, listener, null);

        map = new HashMap<>();
        map.put("u_mail",u_mail);
        map.put("u_pw",u_pw);
    }
    protected Map<String, String> getParams() throws AuthFailureError{
        return map;
    }
}
